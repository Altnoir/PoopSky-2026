local M = {}

function M.modify_property(api, id, original)
    local cache = api:getCachedScriptData()
    if (id == "damage") then
        if (not cache.HIT) then
            if (api:getHeatAmount() > 0) then
                api:removeAmmoFromMagazine(1)
            end
            api:setHeatAmount(math.max(api:getHeatAmount() - 20, 0))
            cache.HIT = true
        end
        api:cacheScriptData(cache)
        if (api:getAttachment("MUZZLE") == "exception_armorer:book_dmg") then
            return 12.5
        elseif (api:getAttachment("MUZZLE") == "exception_armorer:book_dmg_2") then
            return 15
        elseif (api:getAttachment("MUZZLE") == "exception_armorer:book_zenith") then
            return 15
        end
        return 10
    end
    return original
end

-- 过热值拉满也不会过热
function M.handle_shoot_heat(api)end
-- =================================================================================== ↓ 射击 ↓ ===================
function M.shoot(api)
    -- 给 TICK 发出射击信号和延迟秒数
    local cache = api:getCachedScriptData()
    if (cache == nil) then
        cache = {
            reloaded = 0,
            INPUT_SHOOT = false,
            INPUT_SHOOT_DELAY = 0,
            COUNT_SHOOT = -1,
            AMMO_TYPE = "NORMAL",
            EMPTY_COUNT = 0,
            HIT = false
        }
    end
    cache.HIT = false
    cache.INPUT_SHOOT = true
    cache.COUNT_SHOOT = 9
    api:cacheScriptData(cache)
end
-- =================================================================================== ↓ TICK ↓ ===================
function M.tick_heat(api, heatTimestamp)
    -- 初始化一个 cache
    local cache = api:getCachedScriptData()
    if (cache == nil) then
        cache = {
            reloaded = 0,
            INPUT_SHOOT = false,
            INPUT_SHOOT_DELAY = 0,
            COUNT_SHOOT = -1,
            AMMO_TYPE = "NORMAL",
            EMPTY_COUNT = 0,
            HIT = false
        }
    end
    -- 防止弹容空掉，但延迟 2 刻再装填，以便给状态机发消息
    if (api:getAmmoAmount() < 1000) then
        if (cache.EMPTY_COUNT == 0) then
            cache.EMPTY_COUNT = 1
        elseif (cache.EMPTY_COUNT == 1) then
            cache.EMPTY_COUNT = 2
        elseif (cache.EMPTY_COUNT == 2) then
            cache.EMPTY_COUNT = 0
            api:putAmmoInMagazine(1)
        end
    end
    -- 接收到输入的信号才干活
    if (cache.INPUT_SHOOT) then
        if (cache.COUNT_SHOOT == 0) then
            if (api:getAmmoAmount() > 1) then
                api:shootOnce(false)
                api:shootOnce(false)
            else
                api:shootOnce(false)
            end
        end
    end
    -- 时钟
    if (cache.COUNT_SHOOT > -1) then
        cache.COUNT_SHOOT = cache.COUNT_SHOOT -1
    else
        cache.COUNT_SHOOT = -1
    end
    api:cacheScriptData(cache)
end
-- =================================================================================== ↓ 换弹 ↓ ===================
function M.start_reload(api)
    local cache = api:getCachedScriptData()
    if (cache == nil) then
        cache = {
            reloaded = 0,
            INPUT_SHOOT = false,
            INPUT_SHOOT_DELAY = 0,
            COUNT_SHOOT = -1,
            AMMO_TYPE = "NORMAL",
            EMPTY_COUNT = 0,
            HIT = false
        }
    end
    cache.reloaded = 0
    api:cacheScriptData(cache)
    return true
end

local function getReloadTimingFromParam(param)
    local reload_cooldown = param.reload_cooldown * 1000
    local reload_feed = param.reload_feed * 1000
    if (reload_cooldown == nil or reload_feed == nil) then
        return nil
    end
    return reload_cooldown, reload_feed
end

function M.tick_reload(api)
    local param = api:getScriptParams();
    local reload_cooldown, reload_feed = getReloadTimingFromParam(param)
    local reload_time = api:getReloadTime()
    local cache = api:getCachedScriptData()

    if (reload_time < reload_feed) then
        return TACTICAL_RELOAD_FINISHING, reload_feed - reload_time
    elseif (reload_time >= reload_feed and reload_time <= reload_cooldown) then
        -- 处理feed逻辑
        if (cache.reloaded == 0) then
            api:setHeatAmount(api:getHeatMax())
            cache.reloaded = 1
        end
        return TACTICAL_RELOAD_FINISHING, reload_cooldown - reload_time
    elseif (reload_time > reload_cooldown) then
        return NOT_RELOADING, -1
    end
    api:cacheScriptData(cache)
end

return M